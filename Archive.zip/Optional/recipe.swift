//
//  recipe.swift
//  Optional
//
//  Created by John Park on 11/27/17.
//  Copyright © 2017 John Park. All rights reserved.
//

import Foundation

struct recipe {
    var title: String!
    var ingredients: String!
    
    init(title: String, ingredients: String) {
        self.title = title
        self.ingredients = ingredients
    }
}
